#pragma once

namespace nlohmann
{
namespace detail
{
template <typename...>
using void_t = void;
}
}
